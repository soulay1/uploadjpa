package reveng;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the trail_level database table.
 * 
 */
@Entity
@Table(name="trail_level")
@NamedQuery(name="TrailLevel.findAll", query="SELECT t FROM TrailLevel t")
public class TrailLevel implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(unique=true, nullable=false)
	private Integer id;

	@Column(length=2147483647)
	private String code;

	@Column(length=2147483647)
	private String label;

	public TrailLevel() {
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCode() {
		return this.code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getLabel() {
		return this.label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

}