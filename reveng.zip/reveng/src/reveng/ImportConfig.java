package reveng;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Time;
import java.sql.Timestamp;


/**
 * The persistent class for the import_config database table.
 * 
 */
@Entity
@Table(name="import_config")
@NamedQuery(name="ImportConfig.findAll", query="SELECT i FROM ImportConfig i")
public class ImportConfig implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(unique=true, nullable=false)
	private Integer id;

	@Column(name="creation_date")
	private Timestamp creationDate;

	@Column(name="freeze_end_time")
	private Time freezeEndTime;

	@Column(name="freeze_start_time")
	private Time freezeStartTime;

	@Column(length=2147483647)
	private String shedule;

	@Column(name="special_freeze_end_time")
	private Timestamp specialFreezeEndTime;

	@Column(name="special_freeze_start_time")
	private Timestamp specialFreezeStartTime;

	@Column(name="update_date")
	private Timestamp updateDate;

	public ImportConfig() {
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Timestamp getCreationDate() {
		return this.creationDate;
	}

	public void setCreationDate(Timestamp creationDate) {
		this.creationDate = creationDate;
	}

	public Time getFreezeEndTime() {
		return this.freezeEndTime;
	}

	public void setFreezeEndTime(Time freezeEndTime) {
		this.freezeEndTime = freezeEndTime;
	}

	public Time getFreezeStartTime() {
		return this.freezeStartTime;
	}

	public void setFreezeStartTime(Time freezeStartTime) {
		this.freezeStartTime = freezeStartTime;
	}

	public String getShedule() {
		return this.shedule;
	}

	public void setShedule(String shedule) {
		this.shedule = shedule;
	}

	public Timestamp getSpecialFreezeEndTime() {
		return this.specialFreezeEndTime;
	}

	public void setSpecialFreezeEndTime(Timestamp specialFreezeEndTime) {
		this.specialFreezeEndTime = specialFreezeEndTime;
	}

	public Timestamp getSpecialFreezeStartTime() {
		return this.specialFreezeStartTime;
	}

	public void setSpecialFreezeStartTime(Timestamp specialFreezeStartTime) {
		this.specialFreezeStartTime = specialFreezeStartTime;
	}

	public Timestamp getUpdateDate() {
		return this.updateDate;
	}

	public void setUpdateDate(Timestamp updateDate) {
		this.updateDate = updateDate;
	}

}