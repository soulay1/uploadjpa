package reveng;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the file_infos database table.
 * 
 */
@Entity
@Table(name="file_infos")
@NamedQuery(name="FileInfo.findAll", query="SELECT f FROM FileInfo f")
public class FileInfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(unique=true, nullable=false)
	private Integer id;

	@Column(name="creation_date")
	private Timestamp creationDate;

	private Integer filedata;

	@Column(name="local_hash", length=2147483647)
	private String localHash;

	@Column(name="provider_hash", length=2147483647)
	private String providerHash;

	private Integer size;

	private Integer uploadlist;

	private Boolean valid;

	public FileInfo() {
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Timestamp getCreationDate() {
		return this.creationDate;
	}

	public void setCreationDate(Timestamp creationDate) {
		this.creationDate = creationDate;
	}

	public Integer getFiledata() {
		return this.filedata;
	}

	public void setFiledata(Integer filedata) {
		this.filedata = filedata;
	}

	public String getLocalHash() {
		return this.localHash;
	}

	public void setLocalHash(String localHash) {
		this.localHash = localHash;
	}

	public String getProviderHash() {
		return this.providerHash;
	}

	public void setProviderHash(String providerHash) {
		this.providerHash = providerHash;
	}

	public Integer getSize() {
		return this.size;
	}

	public void setSize(Integer size) {
		this.size = size;
	}

	public Integer getUploadlist() {
		return this.uploadlist;
	}

	public void setUploadlist(Integer uploadlist) {
		this.uploadlist = uploadlist;
	}

	public Boolean getValid() {
		return this.valid;
	}

	public void setValid(Boolean valid) {
		this.valid = valid;
	}

}