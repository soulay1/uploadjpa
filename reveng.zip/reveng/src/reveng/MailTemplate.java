package reveng;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the mail_template database table.
 * 
 */
@Entity
@Table(name="mail_template")
@NamedQuery(name="MailTemplate.findAll", query="SELECT m FROM MailTemplate m")
public class MailTemplate implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(unique=true, nullable=false)
	private Integer id;

	@Column(length=2147483647)
	private String content;

	@Column(length=2147483647)
	private String from;

	@Column(length=2147483647)
	private String name;

	@Column(length=2147483647)
	private String subject;

	@Column(length=2147483647)
	private String to;

	public MailTemplate() {
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getContent() {
		return this.content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getFrom() {
		return this.from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSubject() {
		return this.subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getTo() {
		return this.to;
	}

	public void setTo(String to) {
		this.to = to;
	}

}