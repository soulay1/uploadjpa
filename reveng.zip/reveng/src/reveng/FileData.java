package reveng;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the file_data database table.
 * 
 */
@Entity
@Table(name="file_data")
@NamedQuery(name="FileData.findAll", query="SELECT f FROM FileData f")
public class FileData implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(unique=true, nullable=false)
	private Integer id;

	private byte[] content;

	public FileData() {
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public byte[] getContent() {
		return this.content;
	}

	public void setContent(byte[] content) {
		this.content = content;
	}

}