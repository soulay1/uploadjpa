package reveng;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the return_code database table.
 * 
 */
@Entity
@Table(name="return_code")
@NamedQuery(name="ReturnCode.findAll", query="SELECT r FROM ReturnCode r")
public class ReturnCode implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(unique=true, nullable=false)
	private Integer id;

	@Column(length=2147483647)
	private String code;

	@Column(length=2147483647)
	private String description;

	@Column(length=1)
	private String state;

	private Integer step;

	public ReturnCode() {
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCode() {
		return this.code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getState() {
		return this.state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Integer getStep() {
		return this.step;
	}

	public void setStep(Integer step) {
		this.step = step;
	}

}