package reveng;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the import_log database table.
 * 
 */
@Entity
@Table(name="import_log")
@NamedQuery(name="ImportLog.findAll", query="SELECT i FROM ImportLog i")
public class ImportLog implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(unique=true, nullable=false)
	private Integer id;

	private byte[] logfile;

	@Column(length=2147483647)
	private String name;

	@Column(name="records_count")
	private Integer recordsCount;

	public ImportLog() {
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public byte[] getLogfile() {
		return this.logfile;
	}

	public void setLogfile(byte[] logfile) {
		this.logfile = logfile;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getRecordsCount() {
		return this.recordsCount;
	}

	public void setRecordsCount(Integer recordsCount) {
		this.recordsCount = recordsCount;
	}

}