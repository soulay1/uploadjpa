package reveng;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the audit_trail database table.
 * 
 */
@Entity
@Table(name="audit_trail")
@NamedQuery(name="AuditTrail.findAll", query="SELECT a FROM AuditTrail a")
public class AuditTrail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(unique=true, nullable=false)
	private Integer id;

	private Timestamp actiondate;

	@Column(name="automatic_download")
	private Boolean automaticDownload;

	@Column(name="automatic_import")
	private Boolean automaticImport;

	@Column(name="automatic_patches")
	private Boolean automaticPatches;

	@Column(length=2147483647)
	private String comment;

	@Column(name="file_format", length=2147483647)
	private String fileFormat;

	private Integer fileinfo;

	@Column(length=2147483647)
	private String fileurl;

	@Column(name="import_log")
	private Integer importLog;

	@Column(name="list_name", length=2147483647)
	private String listName;

	@Column(length=2147483647)
	private String origin;

	@Column(name="provider_name", length=2147483647)
	private String providerName;

	@Column(name="provider_url", length=2147483647)
	private String providerUrl;

	private Integer returncode;

	@Column(length=2147483647)
	private String status;

	@Column(name="trail_level")
	private Integer trailLevel;

	private Integer user;

	@Column(name="user_defined_format", length=2147483647)
	private String userDefinedFormat;

	public AuditTrail() {
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Timestamp getActiondate() {
		return this.actiondate;
	}

	public void setActiondate(Timestamp actiondate) {
		this.actiondate = actiondate;
	}

	public Boolean getAutomaticDownload() {
		return this.automaticDownload;
	}

	public void setAutomaticDownload(Boolean automaticDownload) {
		this.automaticDownload = automaticDownload;
	}

	public Boolean getAutomaticImport() {
		return this.automaticImport;
	}

	public void setAutomaticImport(Boolean automaticImport) {
		this.automaticImport = automaticImport;
	}

	public Boolean getAutomaticPatches() {
		return this.automaticPatches;
	}

	public void setAutomaticPatches(Boolean automaticPatches) {
		this.automaticPatches = automaticPatches;
	}

	public String getComment() {
		return this.comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getFileFormat() {
		return this.fileFormat;
	}

	public void setFileFormat(String fileFormat) {
		this.fileFormat = fileFormat;
	}

	public Integer getFileinfo() {
		return this.fileinfo;
	}

	public void setFileinfo(Integer fileinfo) {
		this.fileinfo = fileinfo;
	}

	public String getFileurl() {
		return this.fileurl;
	}

	public void setFileurl(String fileurl) {
		this.fileurl = fileurl;
	}

	public Integer getImportLog() {
		return this.importLog;
	}

	public void setImportLog(Integer importLog) {
		this.importLog = importLog;
	}

	public String getListName() {
		return this.listName;
	}

	public void setListName(String listName) {
		this.listName = listName;
	}

	public String getOrigin() {
		return this.origin;
	}

	public void setOrigin(String origin) {
		this.origin = origin;
	}

	public String getProviderName() {
		return this.providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public String getProviderUrl() {
		return this.providerUrl;
	}

	public void setProviderUrl(String providerUrl) {
		this.providerUrl = providerUrl;
	}

	public Integer getReturncode() {
		return this.returncode;
	}

	public void setReturncode(Integer returncode) {
		this.returncode = returncode;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Integer getTrailLevel() {
		return this.trailLevel;
	}

	public void setTrailLevel(Integer trailLevel) {
		this.trailLevel = trailLevel;
	}

	public Integer getUser() {
		return this.user;
	}

	public void setUser(Integer user) {
		this.user = user;
	}

	public String getUserDefinedFormat() {
		return this.userDefinedFormat;
	}

	public void setUserDefinedFormat(String userDefinedFormat) {
		this.userDefinedFormat = userDefinedFormat;
	}

}