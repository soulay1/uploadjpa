package reveng;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the provider_config database table.
 * 
 */
@Entity
@Table(name="provider_config")
@NamedQuery(name="ProviderConfig.findAll", query="SELECT p FROM ProviderConfig p")
public class ProviderConfig implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(unique=true, nullable=false)
	private Integer id;

	private Boolean activate;

	@Column(name="creation_date")
	private Timestamp creationDate;

	@Column(name="download_schedule", length=2147483647)
	private String downloadSchedule;

	private Boolean enable;

	@Column(length=2147483647)
	private String login;

	@Column(length=2147483647)
	private String name;

	@Column(length=2147483647)
	private String password;

	@Column(name="update_date")
	private Timestamp updateDate;

	@Column(length=2147483647)
	private String url;

	public ProviderConfig() {
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Boolean getActivate() {
		return this.activate;
	}

	public void setActivate(Boolean activate) {
		this.activate = activate;
	}

	public Timestamp getCreationDate() {
		return this.creationDate;
	}

	public void setCreationDate(Timestamp creationDate) {
		this.creationDate = creationDate;
	}

	public String getDownloadSchedule() {
		return this.downloadSchedule;
	}

	public void setDownloadSchedule(String downloadSchedule) {
		this.downloadSchedule = downloadSchedule;
	}

	public Boolean getEnable() {
		return this.enable;
	}

	public void setEnable(Boolean enable) {
		this.enable = enable;
	}

	public String getLogin() {
		return this.login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Timestamp getUpdateDate() {
		return this.updateDate;
	}

	public void setUpdateDate(Timestamp updateDate) {
		this.updateDate = updateDate;
	}

	public String getUrl() {
		return this.url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

}