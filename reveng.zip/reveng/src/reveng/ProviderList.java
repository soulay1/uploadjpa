package reveng;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the provider_list database table.
 * 
 */
@Entity
@Table(name="provider_list")
@NamedQuery(name="ProviderList.findAll", query="SELECT p FROM ProviderList p")
public class ProviderList implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(unique=true, nullable=false)
	private Integer id;

	@Column(name="automatic_download")
	private Boolean automaticDownload;

	@Column(name="automatic_import")
	private Boolean automaticImport;

	@Column(name="automatic_patches")
	private Boolean automaticPatches;

	@Column(name="creation_date")
	private Timestamp creationDate;

	private Boolean enable;

	@Column(length=2147483647)
	private String fileformat;

	@Column(length=2147483647)
	private String name;

	@Column(length=2147483647)
	private String origine;

	@Column(nullable=false)
	private Integer provider;

	@Column(name="update_date")
	private Timestamp updateDate;

	@Column(name="user_defined_format", length=2147483647)
	private String userDefinedFormat;

	public ProviderList() {
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Boolean getAutomaticDownload() {
		return this.automaticDownload;
	}

	public void setAutomaticDownload(Boolean automaticDownload) {
		this.automaticDownload = automaticDownload;
	}

	public Boolean getAutomaticImport() {
		return this.automaticImport;
	}

	public void setAutomaticImport(Boolean automaticImport) {
		this.automaticImport = automaticImport;
	}

	public Boolean getAutomaticPatches() {
		return this.automaticPatches;
	}

	public void setAutomaticPatches(Boolean automaticPatches) {
		this.automaticPatches = automaticPatches;
	}

	public Timestamp getCreationDate() {
		return this.creationDate;
	}

	public void setCreationDate(Timestamp creationDate) {
		this.creationDate = creationDate;
	}

	public Boolean getEnable() {
		return this.enable;
	}

	public void setEnable(Boolean enable) {
		this.enable = enable;
	}

	public String getFileformat() {
		return this.fileformat;
	}

	public void setFileformat(String fileformat) {
		this.fileformat = fileformat;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getOrigine() {
		return this.origine;
	}

	public void setOrigine(String origine) {
		this.origine = origine;
	}

	public Integer getProvider() {
		return this.provider;
	}

	public void setProvider(Integer provider) {
		this.provider = provider;
	}

	public Timestamp getUpdateDate() {
		return this.updateDate;
	}

	public void setUpdateDate(Timestamp updateDate) {
		this.updateDate = updateDate;
	}

	public String getUserDefinedFormat() {
		return this.userDefinedFormat;
	}

	public void setUserDefinedFormat(String userDefinedFormat) {
		this.userDefinedFormat = userDefinedFormat;
	}

}