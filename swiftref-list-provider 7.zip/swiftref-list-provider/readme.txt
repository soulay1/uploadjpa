mvn clean package
java -jar swiftref-list-provider-1.jar --spring.config.location=file:./config/ --logging.config=file:./config/logback.xml 
--spring.devtools.restart.additional-paths=file:./config/
jar
log
config
	logback.xml
	config.json
	application.properties
	