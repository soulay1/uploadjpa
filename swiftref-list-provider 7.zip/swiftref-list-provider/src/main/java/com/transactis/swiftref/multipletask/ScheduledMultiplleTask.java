package com.transactis.swiftref.multipletask;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.support.CronTrigger;
import org.springframework.stereotype.Component;

/**
 * The Class ScheduledMultiplleTask.
 */
@Component
public class ScheduledMultiplleTask {

    
/*    @Autowired
    private TaskScheduler taskScheduler;

   
    @Autowired
    private CronConfig cronConfig;

   
    @Autowired
    private MyTask myTask;


    public void scheduleAllCrons() {

        cronConfig.getSchedules().forEach( cron -> taskScheduler.schedule(myTask, new CronTrigger(cron)) );
    }*/
}
