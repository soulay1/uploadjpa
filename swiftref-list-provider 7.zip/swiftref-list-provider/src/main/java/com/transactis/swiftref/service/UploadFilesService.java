package com.transactis.swiftref.service;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.transactis.swiftref.bean.SwiftRefList;
import com.transactis.swiftref.bean.SwiftrefListConfiguration;
import com.transactis.swiftref.utils.JsonUtil;
import com.transactis.swiftref.utils.UploadFilesUtil;

/**
 * The Class UploadFilesService.
 */
@Service
public class UploadFilesService {

	/** The logger. */
	private static Logger logger = LoggerFactory.getLogger("audit-log");
	
	/** The Constant dateTimeFormatter. */
	private static final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss");

	/** The upload files util. */
	@Autowired
	private UploadFilesUtil uploadFilesUtil;
	
	/** The json util. */
	@Autowired
	private JsonUtil jsonUtil;
	
	/** The swiftreflist json file. */
	@Value( "${swiftreflist.json.file}")
	private String swiftreflistJsonFile;
	
	/** The swift ref endpoint. */
	@Value( "${swiftref.endpoint}")
	private String swiftRefEndpoint;
	
	/**
	 * Upload.
	 *
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public void upload() throws IOException {
        SwiftrefListConfiguration buildConfig = jsonUtil.buildConfig(swiftreflistJsonFile);
        processParalleUpload(buildConfig.getSwiftRefLists());
    }
	
	/**
	 * Process paralle upload.
	 *
	 * @param swiftRefLists the swift ref lists
	 */
	private void processParalleUpload(List<SwiftRefList> swiftRefLists) {
		swiftRefLists.parallelStream().forEach(swiftRefList -> {
				logger.info("Start download list name={} destination={} - at {}", swiftRefList.getName(), swiftRefList.getDestinationFolder(), dateTimeFormatter.format(LocalDateTime.now()));
				int response = uploadFilesUtil.downloadUsingSwiftRefApi(swiftRefList.getName(), swiftRefList.getFileFormat(), swiftRefList.getDestinationFolder());
				if (response == 200) {
					logger.info("End download list name={} destination={} - at {}", swiftRefList.getName(), swiftRefList.getDestinationFolder(), dateTimeFormatter.format(LocalDateTime.now()));					
				}
		});
	}

}
