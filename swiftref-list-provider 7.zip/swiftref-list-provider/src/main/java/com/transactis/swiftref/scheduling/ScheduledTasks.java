package com.transactis.swiftref.scheduling;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.transactis.swiftref.service.UploadFilesService;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * The Class ScheduledTasks.
 */
@Component
public class ScheduledTasks {

	/** The logger. */
	private static Logger logger = LoggerFactory.getLogger("audit-log");
	
	/** The Constant dateTimeFormatter. */
	private static final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("YYYY-MM-dd HH:mm:ss");

	/** The swiftreflist json file. */
	@Value("${swiftreflist.json.file}")
	private String swiftreflistJsonFile;

	/** The upload files service. */
	@Autowired
	private UploadFilesService uploadFilesService;

	/**
	 * Schedule task with cron expression.
	 *
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	@Scheduled(cron = "${swiftref.cron.exp}")
	public void scheduleTaskWithCronExpression() throws IOException {
		logger.info("---------------- Start all downloads at- {} ----------------", dateTimeFormatter.format(LocalDateTime.now()));
		uploadFilesService.upload();
		logger.info("---------------- End all downloads at- {} ----------------", dateTimeFormatter.format(LocalDateTime.now()));
	}
}
