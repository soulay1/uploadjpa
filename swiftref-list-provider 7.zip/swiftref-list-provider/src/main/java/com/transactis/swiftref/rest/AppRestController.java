package com.transactis.swiftref.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.transactis.swiftref.bean.SwiftrefListConfiguration;
import com.transactis.swiftref.utils.JsonUtil;

/**
 * The Class AppRestController.
 */
@RestController
public class AppRestController {
	
	/** The env. */
	@Autowired
	private Environment env;
	
	/** The read json file. */
	@Autowired
	private JsonUtil readJsonFile;

	/** The swiftreflist json file. */
	@Value( "${swiftreflist.json.file}" )
	private String swiftreflistJsonFile;
	
    /**
     * Config.
     *
     * @return the string
     */
    @RequestMapping("/config")
    public String config() {
        return swiftreflistJsonFile;
    }
	
    /**
     * Swiftref list configuration.
     *
     * @return the swiftref list configuration
     */
    @RequestMapping("/list")
    public SwiftrefListConfiguration swiftrefListConfiguration() {
        return readJsonFile.buildConfig(swiftreflistJsonFile);
    }
    
	/**
	 * Gets the property value.
	 *
	 * @param key the key
	 * @return the property value
	 */
	@GetMapping("/property")
	public String getPropertyValue(@RequestParam("key") String key) {
		String returnValue = "No value";
		String keyValue = env.getProperty(key);
		if (keyValue != null && !keyValue.isEmpty()) {
			returnValue = keyValue;
		}
		return returnValue;
	}
}
