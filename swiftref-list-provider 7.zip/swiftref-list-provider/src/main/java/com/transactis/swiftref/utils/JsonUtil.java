package com.transactis.swiftref.utils;

import java.io.File;
import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.transactis.swiftref.bean.SwiftrefListConfiguration;

/**
 * The Class JsonUtil.
 */
@Service
public class JsonUtil {
	
	/** The logger. */
	private static Logger logger = LoggerFactory.getLogger(JsonUtil.class);
	
	/**
	 * Builds the config.
	 *
	 * @param filePath the file path
	 * @return the swiftref list configuration
	 */
	public SwiftrefListConfiguration buildConfig(String filePath) {
		SwiftrefListConfiguration config = null;
		ObjectMapper mapper = new ObjectMapper();
		try {
			config = mapper.readValue(new File(filePath), SwiftrefListConfiguration.class);
		} catch (JsonParseException e) {
			logger.error(e.getMessage());
		} catch (JsonMappingException e) {
			logger.error(e.getMessage());
		} catch (IOException e) {
			logger.error(e.getMessage());
		}
		return config;
	}

}
