package com.transactis.swiftref.bean;

/**
 * The Class SwiftRefList.
 */
public class SwiftRefList {
	
	/** The name. */
	private String name;
	
	/** The file format. */
	private String fileFormat;
	
	/** The destination folder. */
	private String destinationFolder;
	
	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * Sets the name.
	 *
	 * @param name the new name
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * Gets the file format.
	 *
	 * @return the file format
	 */
	public String getFileFormat() {
		return fileFormat;
	}
	
	/**
	 * Sets the file format.
	 *
	 * @param fileFormat the new file format
	 */
	public void setFileFormat(String fileFormat) {
		this.fileFormat = fileFormat;
	}
	
	/**
	 * Gets the destination folder.
	 *
	 * @return the destination folder
	 */
	public String getDestinationFolder() {
		return destinationFolder;
	}
	
	/**
	 * Sets the destination folder.
	 *
	 * @param destinationFolder the new destination folder
	 */
	public void setDestinationFolder(String destinationFolder) {
		this.destinationFolder = destinationFolder;
	}

	@Override
	public String toString() {
		return "SwiftRefList [name=" + name + ", fileFormat=" + fileFormat + ", destinationFolder=" + destinationFolder
				+ "]";
	}
	

}
