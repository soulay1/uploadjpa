package com.transactis.swiftref.multipletask;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.ArrayList;
import java.util.List;

/**
 * The Class CronConfig.
 */
@Configuration
@ConfigurationProperties(prefix = "job")
public class CronConfig {

	/** The schedules. */
	private List<String> schedules;

	/**
	 * Schedules.
	 *
	 * @return the list
	 */
	@Bean
	public List<String> schedules() {
		return this.schedules;
	}

	/**
	 * Gets the schedules.
	 *
	 * @return the schedules
	 */
	public List<String> getSchedules() {
		List<String> list = new ArrayList<String>();
		list.add("0 45 9 1/1 * ?");
		list.add("0 46 9 1/1 * ?");
		return list;
	}

	/**
	 * Sets the schedules.
	 *
	 * @param schedules the new schedules
	 */
	public void setSchedules(List<String> schedules) {
		this.schedules = schedules;
	}
}
