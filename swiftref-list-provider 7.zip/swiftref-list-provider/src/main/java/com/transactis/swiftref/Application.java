package com.transactis.swiftref;

import org.springframework.boot.SpringApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.concurrent.ConcurrentTaskScheduler;

import com.transactis.swiftref.multipletask.ScheduledMultiplleTask;

/**
 * The Class Application.
 */
//@SpringBootApplication
@EnableScheduling
@EnableAsync
public class Application {

    /**
     * Task scheduler.
     *
     * @return the task scheduler
     */
    @Bean
    public TaskScheduler taskScheduler() {
        return new ConcurrentTaskScheduler();
    }


    /**
     * The main method.
     *
     * @param args the arguments
     * @throws Exception the exception
     */
/*    public static void main(String[] args) throws Exception {
        ApplicationContext ctx = SpringApplication.run(Application.class);

        ScheduledMultiplleTask scheduledTasks = ctx.getBean(ScheduledMultiplleTask.class);

        scheduledTasks.scheduleAllCrons();
    }*/
}
