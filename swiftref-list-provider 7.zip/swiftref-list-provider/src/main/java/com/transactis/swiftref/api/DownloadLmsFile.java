package com.transactis.swiftref.api;

import java.io.InputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import javax.xml.bind.DatatypeConverter;

public class DownloadLmsFile {
	public static void main(String[] args) {
		// Configuration parameters
		//String iUrl = "https://www.swiftrefdata.com/filesdownload/SLD_US-OFACSDN/std_xml";
		
		// Uncomment the following line to provide the latest downloaded file hash
		// iUrl += "/a994e284e3709e96cf1e5c1ada6fc3a2ec58806be4e9218b407517bf937269ef";

		try {
			// Uncomment the following code, according to the Java version used
			// Java 6: TLS 1.1 support must be explicitly enabled
			// SSLContext context = SSLContext.getInstance("TLSv1.1");
			// context.init(null, null, null);
			// SSLContext.setDefault(context);
			// Java 7: TLS 1.2 support must be explicitly enabled
			// SSLContext context = SSLContext.getInstance("TLSv1.2");
			// context.init(null, null, null);
			// SSLContext.setDefault(context);
			// Java 8 and above: TLS 1.2 support is enabled by default
			// Request is prepared
			String credentials = iUsername + ":" + iPassword;
			String encodedCredentials = DatatypeConverter.printBase64Binary(credentials.getBytes());

			URL url = new URL(iUrl);
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			connection.setRequestProperty("Authorization", "Basic " + encodedCredentials);
			// Request is performed
			switch (connection.getResponseCode()) {
			case 200: // File is sent
				String filePath = connection.getHeaderField("Content-Disposition").split("=")[1];
				// File is downloaded
				InputStream reader = (InputStream) connection.getInputStream();
				FileOutputStream writer = new FileOutputStream(filePath);
				byte[] buffer = new byte[1024];
				int bytesRead = 0;
				while ((bytesRead = reader.read(buffer)) > 0) {
					writer.write(buffer, 0, bytesRead);
				}
				writer.close();
				reader.close();
				// File hash provided by server is compared with the one calculated locally
				String remoteFileHash = connection.getHeaderField("File-Hash");
				String localFileHash = DownloadLmsFile.getFileHash(filePath);
				if (remoteFileHash.equals(localFileHash) == false) {
					System.out.println("Invalid file hash");
				} else {
					System.out.println("File successfully downloaded");
					System.out.println("File hash: " + remoteFileHash);
				}
				break;
			case 204: // File is not sent because already downloaded
				System.out.println("Latest file already downloaded");
				break;
			default:
				// Negative response handling
				System.out.println(connection.getResponseCode() + " " + connection.getResponseMessage());
			}
			connection.disconnect();
		} catch (Exception e) {
			// Custom error handling
			System.out.println(e.getMessage());
		}
	}

	public static String getFileHash(String filePath) throws NoSuchAlgorithmException, IOException {

		MessageDigest md = MessageDigest.getInstance("SHA-256");
		FileInputStream reader = new FileInputStream(filePath);
		byte[] data = new byte[1024];
		int bytesRead = 0;
		while ((bytesRead = reader.read(data)) != -1) {
			md.update(data, 0, bytesRead);
		}
		;
		reader.close();
		byte[] mdbytes = md.digest();
		StringBuffer sb = new StringBuffer("");
		for (int i = 0; i < mdbytes.length; i++) {
			sb.append(Integer.toString((mdbytes[i] & 0xff) + 0x100, 16).substring(1));
		}
		return sb.toString();
	}
}
