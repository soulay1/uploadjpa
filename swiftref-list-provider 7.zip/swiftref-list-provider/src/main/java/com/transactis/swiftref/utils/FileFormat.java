package com.transactis.swiftref.utils;

/**
 * The Enum FileFormat.
 */
public enum FileFormat {
	    
    	/** The std scv. */
    	STD_SCV,
	    
    	/** The std xml. */
    	STD_XML,
	    
    	/** The adv xml. */
    	ADV_XML;
}
