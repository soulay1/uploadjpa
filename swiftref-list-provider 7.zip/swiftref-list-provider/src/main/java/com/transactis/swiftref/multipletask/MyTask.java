package com.transactis.swiftref.multipletask;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.transactis.swiftref.bean.SwiftrefListConfiguration;
import com.transactis.swiftref.utils.JsonUtil;

/**
 * The Class MyTask.
 */
@Component
public class MyTask implements Runnable {
	
	/** The logger. */
	private static Logger logger = LoggerFactory.getLogger("audit-log");
	
	/** The Constant dateTimeFormatter. */
	private static final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss");
	
	/** The json file. */
	@Autowired
	private JsonUtil jsonFile;
	
	/** The swiftreflist json file. */
	@Value( "${swiftreflist.json.file}" )
	private String swiftreflistJsonFile;
	
    /* (non-Javadoc)
     * @see java.lang.Runnable#run()
     */
    @Override
    public void run() {
        logger.info("Cron Task :: Execution Time1 - {}", dateTimeFormatter.format(LocalDateTime.now()));
        SwiftrefListConfiguration buildConfig = jsonFile.buildConfig(swiftreflistJsonFile);
        logger.info("conf : " + buildConfig);
    }
}

