package com.transactis.swiftref.bean;

import java.util.List;

/**
 * The Class SwiftrefListConfiguration.
 */
public class SwiftrefListConfiguration {
	
	/** The swift ref endpoint. */
	private String swiftRefEndpoint;
	
	/** The swift ref lists. */
	private List<SwiftRefList> swiftRefLists;
	
	/**
	 * Gets the swift ref endpoint.
	 *
	 * @return the swift ref endpoint
	 */
	public String getSwiftRefEndpoint() {
		return swiftRefEndpoint;
	}
	
	/**
	 * Sets the swift ref endpoint.
	 *
	 * @param swiftRefEndpoint the new swift ref endpoint
	 */
	public void setSwiftRefEndpoint(String swiftRefEndpoint) {
		this.swiftRefEndpoint = swiftRefEndpoint;
	}
	
	/**
	 * Gets the swift ref lists.
	 *
	 * @return the swift ref lists
	 */
	public List<SwiftRefList> getSwiftRefLists() {
		return swiftRefLists;
	}
	
	/**
	 * Sets the swift ref lists.
	 *
	 * @param swiftRefLists the new swift ref lists
	 */
	public void setSwiftRefLists(List<SwiftRefList> swiftRefLists) {
		this.swiftRefLists = swiftRefLists;
	}

	@Override
	public String toString() {
		return "Config [swiftRefEndpoint=" + swiftRefEndpoint + ", swiftRefLists=" + swiftRefLists + "]";
	}
	
}
