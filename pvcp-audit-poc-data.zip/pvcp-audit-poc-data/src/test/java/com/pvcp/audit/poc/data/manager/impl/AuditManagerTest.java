package com.pvcp.audit.poc.data.manager.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.dozer.DozerBeanMapper;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.pvcp.audit.poc.data.dao.impl.AuditMessageDaoImpl;
import com.pvcp.audit.poc.data.model.MessageRequest;
import com.pvcp.audit.poc.data.model.MessageResponse;
import com.pvcp.audit.poc.data.model.ResponseStatus;
import com.pvcp.audit.poc.service.manager.beans.MessageRequestVo;
import com.pvcp.audit.poc.service.manager.beans.MessageResponseVo;
import com.pvcp.audit.poc.service.manager.impl.AuditManagerImpl;

public class AuditManagerTest {

    @InjectMocks
    private AuditManagerImpl auditManagerImpl;

    @Mock
    private AuditMessageDaoImpl auditMessageDaoImpl;

    /** The dozer mapper. */
    @Mock
    private DozerBeanMapper dozerMapper;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testSave() {
        MessageResponse messageResponse = new MessageResponse();
        String id = "123456";
        ResponseStatus status = ResponseStatus.SUCCESS;
        messageResponse.setId(id);
        messageResponse.setStatus(status);

        Mockito.doNothing().when(auditMessageDaoImpl).save(messageResponse);
        // auditManagerImpl.save(messageResponse);

        assertNotNull(messageResponse);
    }

    // Fixme : correct this
    @Ignore
    @Test
    public void testFindAllMessageRequest() {
        MessageRequest messageRequest1 = new MessageRequest();
        MessageRequest messageRequest2 = new MessageRequest();
        String id1 = "01234";
        String id2 = "56789";
        String userName1 = "abcd";
        String userName2 = "defg";
        messageRequest1.setId(id1);
        messageRequest2.setId(id2);
        messageRequest1.setUserName(userName1);
        messageRequest2.setUserName(userName2);

        ArrayList<MessageRequest> list = new ArrayList<MessageRequest>();
        list.add(messageRequest1);
        list.add(messageRequest2);

        Mockito.when(auditMessageDaoImpl.findAllMessageRequest()).thenReturn(list);
        List<MessageRequestVo> result = auditManagerImpl.findAllMessageRequest();

        assertNotNull(result);
        assertEquals(result.size(), 2);
        assertEquals(result.get(0).getUserName(), userName1);
        assertEquals(result.get(1).getUserName(), userName2);
    }

    // Fixme : correct this
    @Ignore
    @Test
    public void testFindAllMessageResponse() {
        MessageResponse messageResponse1 = new MessageResponse();
        MessageResponse messageResponse2 = new MessageResponse();
        String id1 = "01234";
        String id2 = "56789";
        ResponseStatus status1 = ResponseStatus.SUCCESS;
        ResponseStatus status2 = ResponseStatus.ERROR;
        messageResponse1.setId(id1);
        messageResponse2.setId(id2);
        messageResponse1.setStatus(status1);
        messageResponse2.setStatus(status2);

        ArrayList<MessageResponse> list = new ArrayList<MessageResponse>();
        list.add(messageResponse1);
        list.add(messageResponse2);

        Mockito.when(auditMessageDaoImpl.findAllMessageResponse()).thenReturn(list);
        List<MessageResponseVo> result = auditManagerImpl.findAllMessageResponse();

        assertNotNull(result);
        assertEquals(result.size(), 2);
        assertEquals(result.get(0).getStatus(), status1);
        assertEquals(result.get(1).getStatus(), status2);
    }
}
