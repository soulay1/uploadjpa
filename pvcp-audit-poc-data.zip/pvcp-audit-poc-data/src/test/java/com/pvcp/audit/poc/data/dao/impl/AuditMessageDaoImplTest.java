package com.pvcp.audit.poc.data.dao.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.pvcp.audit.poc.data.model.MessageRequest;
import com.pvcp.audit.poc.data.model.MessageResponse;
import com.pvcp.audit.poc.data.model.ResponseStatus;

public class AuditMessageDaoImplTest {

    protected static EntityManagerFactory emf;

    protected EntityManager em;

    @BeforeClass
    public static void createEntityManagerFactory() {
        emf = Persistence.createEntityManagerFactory("H2UnitTest");
    }

    @AfterClass
    public static void closeEntityManagerFactory() {
        emf.close();
    }

    @Before
    public void beginTransaction() {
        em = emf.createEntityManager();
        em.getTransaction().begin();
    }

    @After
    public void rollbackTransaction() {
        if (em.getTransaction().isActive()) {
            em.getTransaction().rollback();
        }

        if (em.isOpen()) {
            em.close();
        }
    }

    @Test
    public void testSave() {
        AuditMessageDaoImpl auditMessageDaoImpl = new AuditMessageDaoImpl();
        auditMessageDaoImpl.setEntityManager(em);

        MessageRequest messageRequest = new MessageRequest();
        String id = "123456";
        String userName = "abcd";
        messageRequest.setId(id);
        messageRequest.setUserName(userName);

        auditMessageDaoImpl.save(messageRequest);

        messageRequest = null;
        assertNull(messageRequest);

        Query query = em.createQuery("SELECT m FROM MessageRequest m WHERE m.userName = :userName");
        query.setParameter("userName", userName);
        messageRequest = (MessageRequest) query.getSingleResult();

        assertNotNull(messageRequest);
        assertEquals(messageRequest.getId(), id);
        assertEquals(messageRequest.getUserName(), userName);
    }

    @Test
    public void testFindAllMessageRequest() {
        AuditMessageDaoImpl auditMessageDaoImpl = new AuditMessageDaoImpl();
        auditMessageDaoImpl.setEntityManager(em);

        MessageRequest messageRequest1 = new MessageRequest();
        MessageRequest messageRequest2 = new MessageRequest();
        String id1 = "01234";
        String id2 = "56789";
        String userName1 = "abcd";
        String userName2 = "defg";
        messageRequest1.setId(id1);
        messageRequest2.setId(id2);
        messageRequest1.setUserName(userName1);
        messageRequest2.setUserName(userName2);

        auditMessageDaoImpl.save(messageRequest1);
        auditMessageDaoImpl.save(messageRequest2);

        List<MessageRequest> result = auditMessageDaoImpl.findAllMessageRequest();

        assertNotNull(result);
        assertEquals(result.size(), 2);
        assertEquals(result.get(0).getUserName(), userName1);
        assertEquals(result.get(1).getUserName(), userName2);
    }

    @Test
    public void testFindAllMessageResponse() {
        AuditMessageDaoImpl auditMessageDaoImpl = new AuditMessageDaoImpl();
        auditMessageDaoImpl.setEntityManager(em);

        MessageResponse messageResponse1 = new MessageResponse();
        MessageResponse messageResponse2 = new MessageResponse();
        String id1 = "01234";
        String id2 = "56789";
        ResponseStatus status1 = ResponseStatus.ERROR;
        ResponseStatus status2 = ResponseStatus.SUCCESS;
        messageResponse1.setId(id1);
        messageResponse2.setId(id2);
        messageResponse1.setStatus(status1);
        messageResponse2.setStatus(status2);

        auditMessageDaoImpl.save(messageResponse1);
        auditMessageDaoImpl.save(messageResponse2);

        List<MessageResponse> result = auditMessageDaoImpl.findAllMessageResponse();

        assertNotNull(result);
        assertEquals(result.size(), 2);
        assertEquals(result.get(0).getStatus(), status1);
        assertEquals(result.get(1).getStatus(), status2);
    }

}
