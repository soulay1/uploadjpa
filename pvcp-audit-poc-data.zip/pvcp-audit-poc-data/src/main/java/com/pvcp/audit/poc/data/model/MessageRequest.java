package com.pvcp.audit.poc.data.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "MESSAGES_REQUEST")
public class MessageRequest extends AuditMessage {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** The esb. */
    private String esb;

    /** The host. */
    private String host;

    /** The type. */
    private String type;

    /** The format. */
    private String format;

    /** The user name. */
    private String userName;

    /** The requester. */
    private String requester;

    /** The transaction date. */
    private Date transactionDate;

    /** The group id. */
    private Long groupId;

    /** The object id. */
    private String objectId;

    /** The direction. */
    private String direction;

    /** The service name. */
    private String serviceName;

    /** The service address. */
    private String serviceAddress;

    /**
     * Default constructor.
     */
    public MessageRequest() {
    }

    /**
     * Gets the esb.
     *
     * @return the esb
     */
    @Column(name = "ESB")
    public String getEsb() {
        return esb;
    }

    /**
     * Sets the esb.
     *
     * @param esb
     *            the esb to set
     */
    public void setEsb(String esb) {
        this.esb = esb;
    }

    /**
     * Gets the host.
     *
     * @return the host
     */
    @Column(name = "HOST")
    public String getHost() {
        return host;
    }

    /**
     * Sets the host.
     *
     * @param host
     *            the host to set
     */
    public void setHost(String host) {
        this.host = host;
    }

    /**
     * Gets the type.
     *
     * @return the type
     */
    @Column(name = "TYPE")
    public String getType() {
        return type;
    }

    /**
     * Sets the type.
     *
     * @param type
     *            the type to set
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * Gets the format.
     *
     * @return the format
     */
    @Column(name = "FORMAT")
    public String getFormat() {
        return format;
    }

    /**
     * Sets the format.
     *
     * @param format
     *            the format to set
     */
    public void setFormat(String format) {
        this.format = format;
    }

    /**
     * Gets the user name.
     *
     * @return the userName
     */
    @Column(name = "USER_NAME")
    public String getUserName() {
        return userName;
    }

    /**
     * Sets the user name.
     *
     * @param userName
     *            the userName to set
     */
    public void setUserName(String userName) {
        this.userName = userName;
    }

    /**
     * Gets the requester.
     *
     * @return the requester
     */
    @Column(name = "REQUESTER")
    public String getRequester() {
        return requester;
    }

    /**
     * Sets the requester.
     *
     * @param requester
     *            the requester to set
     */
    public void setRequester(String requester) {
        this.requester = requester;
    }

    /**
     * Gets the transaction date.
     *
     * @return the transactionDate
     */
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "DT_TRANSACTION")
    public Date getTransactionDate() {
        return transactionDate;
    }

    /**
     * Sets the transaction date.
     *
     * @param transactionDate
     *            the transactionDate to set
     */
    public void setTransactionDate(Date transactionDate) {
        this.transactionDate = transactionDate;
    }

    /**
     * Gets the group id.
     *
     * @return the groupId
     */
    @Column(name = "GROUP_ID")
    public Long getGroupId() {
        return groupId;
    }

    /**
     * Sets the group id.
     *
     * @param groupId
     *            the groupId to set
     */
    public void setGroupId(Long groupId) {
        this.groupId = groupId;
    }

    /**
     * Gets the object id.
     *
     * @return the objectId
     */
    @Column(name = "OBJECT_ID")
    public String getObjectId() {
        return objectId;
    }

    /**
     * Sets the object id.
     *
     * @param objectId
     *            the objectId to set
     */
    public void setObjectId(String objectId) {
        this.objectId = objectId;
    }

    /**
     * Gets the direction.
     *
     * @return the direction
     */
    @Column(name = "DIRECTION")
    public String getDirection() {
        return direction;
    }

    /**
     * Sets the direction.
     *
     * @param direction
     *            the direction to set
     */
    public void setDirection(String direction) {
        this.direction = direction;
    }

    /**
     * Gets the service name.
     *
     * @return the serviceName
     */
    @Column(name = "SERVICE_NAME")
    public String getServiceName() {
        return serviceName;
    }

    /**
     * Sets the service name.
     *
     * @param serviceName
     *            the serviceName to set
     */
    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    /**
     * Gets the service address.
     *
     * @return the service address
     */
    @Column(name = "SERVICE_ADDRESS")
    public String getServiceAddress() {
        return serviceAddress;
    }

    /**
     * Sets the service address.
     *
     * @param serviceAddress
     *            the new service address
     */
    public void setServiceAddress(String serviceAddress) {
        this.serviceAddress = serviceAddress;
    }
}
