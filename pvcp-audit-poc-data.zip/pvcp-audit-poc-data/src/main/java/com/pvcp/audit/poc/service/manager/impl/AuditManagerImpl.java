/**
 * 
 */
package com.pvcp.audit.poc.service.manager.impl;

import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.ClipboardOwner;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.Transferable;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.StringWriter;
import java.sql.Clob;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;
import org.dozer.DozerBeanMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.pvcp.audit.poc.data.criteria.MessageRequestSearchCriteria;
import com.pvcp.audit.poc.data.dao.AuditMessageDao;
import com.pvcp.audit.poc.data.model.MessageRequest;
import com.pvcp.audit.poc.data.model.MessageResponse;
import com.pvcp.audit.poc.service.manager.AuditManager;
import com.pvcp.audit.poc.service.manager.beans.MessageRequestVo;
import com.pvcp.audit.poc.service.manager.beans.MessageResponseVo;

@Service("auditManager")
@Transactional
public class AuditManagerImpl implements AuditManager, Serializable {

    /**
     * UUID
     */
    private static final long serialVersionUID = 6534965380644981958L;

    /**
     * A logger for this class
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(AuditManagerImpl.class);

    /** The message dead line dao. */
    @Autowired
    private AuditMessageDao auditMessageDao;

    /** The dozer mapper. */
    @Autowired
    @Qualifier("dozerMapper")
    private transient DozerBeanMapper dozerMapper;

    @Override
    public List<MessageRequestVo> findAllMessageRequest() {
        List<MessageRequestVo> listOfResults = new ArrayList<MessageRequestVo>();

        List<MessageRequest> listOfMessageRequests = auditMessageDao.findAllMessageRequest();
        for (MessageRequest messageRequest : listOfMessageRequests) {
            MessageRequestVo requestVo = dozerMapper.map(messageRequest, MessageRequestVo.class);
            String message = clobToString(messageRequest.getMessage());
            String indentMessage = formatXML(message);
            requestVo.setMessage(indentMessage);
            listOfResults.add(requestVo);
        }
        return listOfResults;
    }

    @Override
    public List<MessageResponseVo> findAllMessageResponse() {
        List<MessageResponseVo> listOfResults = new ArrayList<MessageResponseVo>();

        List<MessageResponse> listOfMessageResponses = auditMessageDao.findAllMessageResponse();
        for (MessageResponse resp : listOfMessageResponses) {
            MessageResponseVo responseVo = dozerMapper.map(resp, MessageResponseVo.class);
            String message = clobToString(resp.getMessage());
            String indentMessage = formatXML(message);
            responseVo.setMessage(indentMessage);
            listOfResults.add(responseVo);
        }
        return listOfResults;
    }

    @Override
    public List<String> findDistinctTypeFromMessageRequest() {
        return auditMessageDao.findDistinctTypeFromMessageRequest();
    }

    @Override
    public List<String> findAllMessageRequestESB() {
        return auditMessageDao.findAllMessageRequestESB();
    }

    @Override
    public List<String> findAllMessageRequestHost() {
        return auditMessageDao.findAllMessageRequestHost();
    }

    @Override
    public List<String> findAllMessageRequestFormat() {
        return auditMessageDao.findAllMessageRequestFormat();
    }

    @Override
    public List<MessageRequestVo> findAllMessageRequestCriteria(MessageRequestSearchCriteria messageRequestSearchCriteria) {
        List<MessageRequestVo> listOfResults = new ArrayList<MessageRequestVo>();

        List<MessageRequest> listOfMessageRequests = auditMessageDao.findAllMessageRequestCriteria(messageRequestSearchCriteria);
        for (MessageRequest req : listOfMessageRequests) {
            MessageRequestVo requestVo = dozerMapper.map(req, MessageRequestVo.class);
            String message = clobToString(req.getMessage());
            String indentMessage = formatXML(message);
            requestVo.setMessage(indentMessage);
            MessageResponse resp = findMessageResponseByMessageRequestId(req.getId());
            if (resp != null) {
                String messageFromResponse = clobToString(resp.getMessage());
                String indentMessageFromResponse = formatXML(messageFromResponse);
                requestVo.setStatusOfMessageResponse(resp.getStatus());
                requestVo.setMessageResponseMessage(indentMessageFromResponse);
                requestVo.setResponseTransactionDate(resp.getTransactionDate());
            }

            List<MessageRequestVo> listOfResultsGroupId = new ArrayList<MessageRequestVo>();
            List<MessageRequest> listOfMessageRequestGroupId = findMessageRequestByGroupId(req.getGroupId());
            boolean requestWithGroup = true;
            for (MessageRequest reqGroupId : listOfMessageRequestGroupId) {
                boolean requestGroupAfter = reqGroupId.getTransactionDate().after(req.getTransactionDate())
                        || reqGroupId.getTransactionDate().equals(req.getTransactionDate());
                boolean sameType = reqGroupId.getType() != null && reqGroupId.getType().equals(req.getType()) && requestGroupAfter;
                boolean differentType = reqGroupId.getType() != null && !reqGroupId.getType().equals(req.getType()) && requestGroupAfter;
                if (sameType || differentType) {
                    MessageRequestVo requestVoGroupId = dozerMapper.map(reqGroupId, MessageRequestVo.class);
                    String messageGroupId = clobToString(reqGroupId.getMessage());
                    String indentMessageGroupId = formatXML(messageGroupId);
                    requestVoGroupId.setMessage(indentMessageGroupId);
                    MessageResponse respGroupId = findMessageResponseByMessageRequestId(reqGroupId.getId());
                    if (respGroupId != null) {
                        requestVoGroupId.setStatusOfMessageResponse(respGroupId.getStatus());
                        String messageFromResponse = clobToString(respGroupId.getMessage());
                        String indentMessageFromResponse = formatXML(messageFromResponse);
                        requestVoGroupId.setMessageResponseMessage(indentMessageFromResponse);
                        requestVoGroupId.setResponseTransactionDate(respGroupId.getTransactionDate());
                    }
                    if (!reqGroupId.getId().equals(req.getId())) {
                        listOfResultsGroupId.add(requestVoGroupId);
                    }
                } else {
                    requestWithGroup = false;
                }
            }
            if (requestWithGroup) {
                requestVo.setGroupMessageRequest(listOfResultsGroupId);
            }
            listOfResults.add(requestVo);
        }
        return listOfResults;
    }

    @Override
    public MessageResponse findMessageResponseByMessageRequestId(String id) {
        return auditMessageDao.findMessageResponseByMessageRequestId(id);
    }

    @Override
    public List<MessageRequest> findMessageRequestByGroupId(Long groupId) {
        return auditMessageDao.findMessageRequestByGroupId(groupId);
    }

    // PRIVATE METHOD

    private String clobToString(Clob data) {
        StringBuilder sb = new StringBuilder();
        try {
            Reader reader = data.getCharacterStream();
            BufferedReader br = new BufferedReader(reader);

            String line;
            while (null != (line = br.readLine())) {
                sb.append(line);
            }
            br.close();
        } catch (SQLException e) {
            LOGGER.error("Could not convert CLOB to string", e);
            return e.toString();
        } catch (IOException e) {
            LOGGER.error("Could not convert CLOB to string", e);
            return e.toString();
        }
        return sb.toString();
    }

    private String formatXML(String input) {
        try {
            Document doc = DocumentHelper.parseText(input);
            StringWriter sw = new StringWriter();
            OutputFormat format = OutputFormat.createPrettyPrint();
            format.setIndent(true);
            format.setIndentSize(3);
            XMLWriter xw = new XMLWriter(sw, format);
            xw.write(doc);

            return sw.toString();
        } catch (DocumentException | IOException e) {
            LOGGER.error("Error while formatting XML", e);
            return input;
        }
    }

    public void writeToClipboard(String s, ClipboardOwner owner) {
        Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
        Transferable transferable = new StringSelection(s);
        clipboard.setContents(transferable, owner);
    }

}
