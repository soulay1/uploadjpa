package com.pvcp.audit.poc.data.dao.impl;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.pvcp.audit.poc.data.criteria.MessageRequestSearchCriteria;
import com.pvcp.audit.poc.data.dao.AuditMessageDao;
import com.pvcp.audit.poc.data.model.AuditMessage;
import com.pvcp.audit.poc.data.model.MessageRequest;
import com.pvcp.audit.poc.data.model.MessageResponse;

@Repository("auditMessage")
public class AuditMessageDaoImpl implements AuditMessageDao, Serializable {

    /**
     * UUID
     */
    private static final long serialVersionUID = 4140490309525683711L;

    @PersistenceContext
    private EntityManager entityManager;

    public EntityManager getEntityManager() {
        return entityManager;
    }

    public void setEntityManager(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    @Override
    public void save(AuditMessage auditMessage) {
        entityManager.persist(auditMessage);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<MessageRequest> findAllMessageRequest() {
        Query query = entityManager.createQuery("SELECT m FROM MessageRequest m");
        return (List<MessageRequest>) query.getResultList();
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<MessageResponse> findAllMessageResponse() {
        Query query = entityManager.createQuery("SELECT m FROM MessageResponse m");
        query.setMaxResults(10);
        return (List<MessageResponse>) query.getResultList();
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<String> findDistinctTypeFromMessageRequest() {
        Query query = entityManager.createQuery("SELECT DISTINCT m.type FROM MessageRequest m ORDER BY m.type ASC");
        return query.getResultList();
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<String> findAllMessageRequestESB() {
        Query query = entityManager.createQuery("SELECT DISTINCT m.esb FROM MessageRequest m");
        return query.getResultList();
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<String> findAllMessageRequestHost() {
        Query query = entityManager.createQuery("SELECT DISTINCT m.host FROM MessageRequest m");
        return query.getResultList();
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<String> findAllMessageRequestFormat() {
        Query query = entityManager.createQuery("SELECT DISTINCT m.format FROM MessageRequest m");
        return query.getResultList();
    }

    // @SuppressWarnings("unchecked")
    // @Override
    // public List<MessageRequest> findAllMessageRequestCriteria(MessageRequestSearchCriteria
    // messageRequestSearchCriteria) {
    // String queryString = "SELECT m FROM MessageRequest m";
    // String type = null;
    //
    // if (messageRequestSearchCriteria.getType() != null) {
    // type = messageRequestSearchCriteria.getType();
    // queryString = queryString + " WHERE m.type = :type";
    // }
    //
    // Query query = entityManager.createQuery(queryString);
    //
    // if (type != null) {
    // query.setParameter("type", type);
    // }
    //
    // return query.getResultList();
    // }

    @Override
    public List<MessageRequest> findAllMessageRequestCriteria(MessageRequestSearchCriteria messageRequestSearchCriteria) {
        List<MessageRequest> result;
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<MessageRequest> criteriaQuery = criteriaBuilder.createQuery(MessageRequest.class);
        Root<MessageRequest> root = criteriaQuery.from(MessageRequest.class);

        // Constructing list of parameters
        List<Predicate> predicates = new ArrayList<Predicate>();

        if (messageRequestSearchCriteria.getTypes() != null && messageRequestSearchCriteria.getTypes().length > 0) {
            predicates.add(root.get("type").in(Arrays.asList(messageRequestSearchCriteria.getTypes())));
        }
        if (messageRequestSearchCriteria.getStartDate() != null) {
            Expression<Date> transactionDate = root.get("transactionDate");
            predicates.add(criteriaBuilder.greaterThan(transactionDate, messageRequestSearchCriteria.getStartDate()));
        }
        if (messageRequestSearchCriteria.getEndDate() != null) {
            Expression<Date> transactionDate = root.get("transactionDate");
            predicates.add(criteriaBuilder.lessThanOrEqualTo(transactionDate, messageRequestSearchCriteria.getEndDate()));
        }
        if (messageRequestSearchCriteria.getObjectId() != null) {
            predicates.add(criteriaBuilder.equal(root.get("objectId"), messageRequestSearchCriteria.getObjectId()));
        }

        // query itself
        criteriaQuery.select(root).where(predicates.toArray(new Predicate[] {}));
        if (messageRequestSearchCriteria.getEndDate() != null || messageRequestSearchCriteria.getStartDate() != null) {
            criteriaQuery.orderBy(criteriaBuilder.desc(root.get("transactionDate")));
        }
        if (messageRequestSearchCriteria.getMaxResult() != null) {
            result = entityManager.createQuery(criteriaQuery).setMaxResults(Integer.valueOf(messageRequestSearchCriteria.getMaxResult()))
                    .getResultList();
        } else {
            result = entityManager.createQuery(criteriaQuery).getResultList();
        }
        return result;
    }

    @Override
    public MessageResponse findMessageResponseByMessageRequestId(String id) {
        Query query = entityManager.createQuery("SELECT m FROM MessageResponse m WHERE m.correlationId = :id");
        query.setParameter("id", id);
        @SuppressWarnings("unchecked")
        List<MessageResponse> listResult = query.getResultList();
        if (listResult.isEmpty()) {
            return null;
        } else {
            return listResult.get(0);
        }
    }

    @Override
    public List<MessageRequest> findMessageRequestByGroupId(Long groupId) {
        Query query = entityManager.createQuery("SELECT m FROM MessageRequest m WHERE m.groupId = :groupId order by transactionDate ASC");
        query.setParameter("groupId", groupId);
        @SuppressWarnings("unchecked")
        List<MessageRequest> listResult = query.getResultList();
        return listResult;

    }

}
