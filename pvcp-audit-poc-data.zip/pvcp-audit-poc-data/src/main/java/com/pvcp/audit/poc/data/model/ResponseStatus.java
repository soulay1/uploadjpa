package com.pvcp.audit.poc.data.model;

public enum ResponseStatus {
    SUCCESS("SUCCESS"), ERROR("ERROR"), WARNING("WARNING");

    /**
     * The value.
     */
    private String value;

    /**
     * Instantiates a new {@link ResponseStatus}.
     * 
     * @param v
     *            the v
     */
    ResponseStatus(String v) {
        value = v;
    }

    /**
     * Value.
     * 
     * @return the string
     */
    public String value() {
        return value;
    }
}
