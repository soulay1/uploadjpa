package com.pvcp.audit.poc.service.manager.beans;

import java.io.Serializable;
import java.util.Date;

import lombok.Data;

import com.pvcp.audit.poc.data.model.ResponseStatus;

@Data
@SuppressWarnings("PMD.UnusedPrivateField")
public class MessageResponseVo implements Serializable {

    private static final long serialVersionUID = -30107021198552810L;

    /** The id. */
    private String id;

    /** The message. */
    private String message;

    /** The creation date. */
    private Date creationDate;

    /** The status. */
    private ResponseStatus status;

    /** The correlation id. */
    private String correlationId;

    /** The transaction date. */
    private Date transactionDate;

}
