package com.pvcp.audit.poc.data.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "MESSAGES_RESPONSE")
public class MessageResponse extends AuditMessage {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** The status. */
    private ResponseStatus status;

    /** The correlation id. */
    private String correlationId;

    /** The transaction date. */
    private Date transactionDate;

    /**
     * Default constructor.
     */
    public MessageResponse() {
    }

    /**
     * Gets the status.
     *
     * @return the status
     */
    @Enumerated(EnumType.STRING)
    @Column(name = "STATUS")
    public ResponseStatus getStatus() {
        return status;
    }

    /**
     * Sets the status.
     *
     * @param status
     *            the status to set
     */
    public void setStatus(ResponseStatus status) {
        this.status = status;
    }

    /**
     * Gets the correlation id.
     *
     * @return the correlationId
     */
    @Column(name = "COR_ID")
    public String getCorrelationId() {
        return correlationId;
    }

    /**
     * Sets the correlation id.
     *
     * @param correlationId
     *            the correlationId to set
     */
    public void setCorrelationId(String correlationId) {
        this.correlationId = correlationId;
    }

    /**
     * Gets the transaction date.
     *
     * @return the transactionDate
     */
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "DT_TRANSACTION")
    public Date getTransactionDate() {
        return transactionDate;
    }

    /**
     * Sets the transaction date.
     *
     * @param transactionDate
     *            the transactionDate to set
     */
    public void setTransactionDate(Date transactionDate) {
        this.transactionDate = transactionDate;
    }

}
