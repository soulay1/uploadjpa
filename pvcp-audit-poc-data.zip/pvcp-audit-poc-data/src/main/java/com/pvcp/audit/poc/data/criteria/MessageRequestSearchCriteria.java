package com.pvcp.audit.poc.data.criteria;

import java.io.Serializable;
import java.sql.Clob;
import java.util.Date;

import lombok.Getter;
import lombok.Setter;

/**
 * This class contains all criteria fields
 * 
 * @author wbedrici
 *
 */
@SuppressWarnings("PMD.UnusedPrivateField")
public class MessageRequestSearchCriteria implements Serializable {

    /**
     * UUID
     */
    private static final long serialVersionUID = -2094954545263203318L;

    @Getter
    @Setter
    /** The id. */
    private String id;

    @Getter
    @Setter
    /** The message. */
    private Clob message;

    @Getter
    @Setter
    /** The creation date. */
    private Date creationDate;

    @Getter
    @Setter
    /** The esb. */
    private String esb;

    @Getter
    @Setter
    /** The host. */
    private String host;

    @Getter
    @Setter
    /** The type. */
    private String type;

    @Getter
    @Setter
    private String[] types;

    @Getter
    @Setter
    /** The format. */
    private String format;

    @Getter
    @Setter
    /** The user name. */
    private String userName;

    @Getter
    @Setter
    /** The requester. */
    private String requester;

    @Getter
    @Setter
    /** The transaction date. */
    private Date transactionDate;

    @Getter
    @Setter
    /** The group id. */
    private Long groupId;

    @Getter
    @Setter
    /** The object id. */
    private String objectId;

    @Getter
    @Setter
    /** The direction. */
    private String direction;

    @Getter
    @Setter
    /** The service name. */
    private String serviceName;

    @Getter
    @Setter
    /** The service date. */
    private Date startDate;

    @Getter
    @Setter
    /** The service date. */
    private Date endDate;

    @Getter
    @Setter
    /** The service address. */
    private String serviceAddress;

    @Getter
    @Setter
    /** max result to return . */
    private String maxResult;

}
