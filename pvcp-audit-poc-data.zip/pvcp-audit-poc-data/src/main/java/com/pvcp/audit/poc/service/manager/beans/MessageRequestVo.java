package com.pvcp.audit.poc.service.manager.beans;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import lombok.Data;

import com.pvcp.audit.poc.data.model.ResponseStatus;

@Data
@SuppressWarnings("PMD.UnusedPrivateField")
public class MessageRequestVo implements Serializable {

    private static final long serialVersionUID = 5464807649131343100L;

    /** The id. */
    private String id;

    /** The message. */
    private String message;

    /** The creation date. */
    private Date creationDate;

    /** The esb. */
    private String esb;

    /** The host. */
    private String host;

    /** The type. */
    private String type;

    /** The format. */
    private String format;

    /** The user name. */
    private String userName;

    /** The requester. */
    private String requester;

    /** The transaction date. */
    private Date transactionDate;

    /** The group id. */
    private Long groupId;

    /** The object id. */
    private String objectId;

    /** The direction. */
    private String direction;

    /** The service name. */
    private String serviceName;

    /** The service address. */
    private String serviceAddress;

    /** The MessageResponse message . */
    private String messageResponseMessage;

    /** The List of MessageRequest by groupId . */
    private List<MessageRequestVo> groupMessageRequest;

    /** The status of MessageResponse . */
    private ResponseStatus statusOfMessageResponse;

    private Date responseTransactionDate;

    public long getResponseTime() {
        if (responseTransactionDate == null) {
            return 0;
        }
        return responseTransactionDate.getTime() - transactionDate.getTime();
    }
}
