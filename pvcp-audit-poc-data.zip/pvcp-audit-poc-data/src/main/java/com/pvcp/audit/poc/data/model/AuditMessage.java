package com.pvcp.audit.poc.data.model;

import java.io.Serializable;
import java.sql.Clob;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@MappedSuperclass
public class AuditMessage implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** The id. */
    private String id;

    /** The message. */
    private Clob message;

    /** The creation date. */
    private Date creationDate;

    /**
     * Default constructor.
     */
    public AuditMessage() {
    }

    /**
     * Gets the id.
     * 
     * @return the id
     */
    @Id
    public String getId() {
        return id;
    }

    /**
     * Sets the id.
     * 
     * @param id
     *            the id to set
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * Gets the message.
     *
     * @return the message
     */
    @Column(name = "MSG")
    public Clob getMessage() {
        return message;
    }

    /**
     * Sets the message.
     *
     * @param message
     *            the new message
     */
    public void setMessage(Clob message) {
        this.message = message;
    }

    /**
     * Gets the creation date.
     * 
     * @return the creationDate
     */
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "DT_CREATION")
    public Date getCreationDate() {
        return creationDate;
    }

    /**
     * Sets the creation date.
     * 
     * @param creationDate
     *            the creationDate to set
     */
    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

}
