package com.pvcp.audit.poc.data.dao;

import java.util.List;

import com.pvcp.audit.poc.data.criteria.MessageRequestSearchCriteria;
import com.pvcp.audit.poc.data.model.AuditMessage;
import com.pvcp.audit.poc.data.model.MessageRequest;
import com.pvcp.audit.poc.data.model.MessageResponse;

public interface AuditMessageDao {

    /**
     * Save.
     *
     * @param auditMessage
     *            the audit message
     */
    void save(AuditMessage auditMessage);

    /**
     * Find all Message Request.
     *
     * @return the list
     */
    List<MessageRequest> findAllMessageRequest();

    /**
     * Find all Message Response.
     *
     * @return the list
     */
    List<MessageResponse> findAllMessageResponse();

    /**
     * Find all Message Request Type
     * 
     * @return list
     */
    List<String> findDistinctTypeFromMessageRequest();

    /**
     * Find all Message Request ESB
     * 
     * @return list
     */
    List<String> findAllMessageRequestESB();

    /**
     * Find all Message Request Host
     * 
     * @return list
     */
    List<String> findAllMessageRequestHost();

    /**
     * Find all Message Request Format
     * 
     * @return list
     */
    List<String> findAllMessageRequestFormat();

    /**
     * Find all Message Request with filter
     * 
     * @return list
     */
    List<MessageRequest> findAllMessageRequestCriteria(MessageRequestSearchCriteria messageRequestSearchCriteria);

    /**
     * Find Message Response by Message Request Id
     * 
     * @return MessageResponse
     */
    MessageResponse findMessageResponseByMessageRequestId(String id);

    /**
     * Find Message Request by groupId
     * 
     * @return list
     */
    List<MessageRequest> findMessageRequestByGroupId(Long groupId);
}